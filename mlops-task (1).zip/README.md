# MLOps Task 0 — Rolling-Mean Signal Batch Job

A minimal, reproducible MLOps-style batch job that reads OHLCV data, computes a
rolling mean on `close`, derives a binary trading signal, and emits
machine-readable metrics plus structured logs. Built for deterministic,
containerized execution.

## What it does

1. Loads and validates `config.yaml` (`seed`, `window`, `version`).
2. Sets `numpy.random.seed(seed)` for reproducibility.
3. Loads and validates `data.csv` (checks file exists, is non-empty, is
   parsable, and contains a `close` column).
4. Computes a rolling mean of `close` over `window` periods.
5. Derives `signal = 1 if close > rolling_mean else 0`.
   - The first `window - 1` rows have no defined rolling mean; they are
     excluded from the rolling-mean-based comparison and default to
     `signal = 0` (documented, consistent convention — no lookahead bias).
6. Computes `rows_processed`, `signal_rate` (mean of `signal`), and
   `latency_ms` (total runtime).
7. Writes `metrics.json` (always — success or failure) and `run.log`
   (detailed, timestamped logs of every step).
8. Prints the final metrics JSON to stdout and exits `0` on success,
   non-zero on failure.

## Files

| File | Purpose |
|---|---|
| `run.py` | Main pipeline script |
| `config.yaml` | Run configuration (`seed`, `window`, `version`) |
| `data.csv` | Sample 10,000-row synthetic OHLCV dataset |
| `requirements.txt` | Pinned Python dependencies |
| `Dockerfile` | Container build definition |
| `metrics.json` | Sample output from a successful run |
| `run.log` | Sample log from a successful run |
| `generate_data.py` | (Optional) script used to synthesize `data.csv`; not part of the graded pipeline |

## Local run instructions

Requires Python 3.9+.

```bash
pip install -r requirements.txt

python run.py \
  --input data.csv \
  --config config.yaml \
  --output metrics.json \
  --log-file run.log
```

No paths are hard-coded — `--input`, `--config`, `--output`, and `--log-file`
are all supplied via CLI flags and can point anywhere on disk.

The command prints the final metrics JSON to stdout and exits with code `0`
on success or non-zero on failure (with `metrics.json` still written in the
error case, containing `status: "error"` and an `error_message`).

## Docker build & run

```bash
docker build -t mlops-task .
docker run --rm mlops-task
```

The image bundles `data.csv` and `config.yaml`, runs the pipeline on build's
default `CMD`, prints the metrics JSON to stdout, and writes
`/app/metrics.json` and `/app/run.log` inside the container. To persist
those outputs to your host machine, mount a volume:

```bash
docker run --rm -v "$(pwd)/out:/app" mlops-task
# metrics.json and run.log will appear in ./out on the host
```

## Example `metrics.json` (success)

```json
{
  "version": "v1",
  "rows_processed": 10000,
  "metric": "signal_rate",
  "value": 0.4821,
  "latency_ms": 18,
  "seed": 42,
  "status": "success"
}
```

## Example `metrics.json` (error)

```json
{
  "version": "v1",
  "status": "error",
  "error_message": "Missing required column: 'close'"
}
```

## Error handling covered

- Missing input file
- Empty input file
- Invalid / malformed CSV
- Missing required `close` column
- Invalid or incomplete config structure (missing/invalid `seed`, `window`,
  `version`)
- `window` larger than the number of available rows

In every case, `metrics.json` is still written (with `status: "error"` and a
descriptive `error_message`), the failure is logged to `run.log`, and the
process exits with a non-zero status code.

## Optional: visual dashboard

`dashboard.html` is a small, self-contained bonus page that visualizes what
the pipeline does and shows real output from the last run — pipeline steps,
metrics cards, a close-price-vs-rolling-mean chart with signal markers, and
the actual `run.log`. It's a presentation aid only; the graded pipeline is
`run.py`, and it has no frontend dependency.

Open it directly in a browser (no server needed):

```bash
open dashboard.html        # macOS
```

To refresh it with fresh data after a new run:

```bash
python run.py --input data.csv --config config.yaml --output metrics.json --log-file run.log
python generate_dashboard.py
```

## Reproducibility notes

- `numpy.random.seed(config.seed)` is set before any data processing.
- The rolling-mean/signal computation is a deterministic, order-preserving
  pandas operation — identical inputs and config always produce an identical
  `signal_rate` (only `latency_ms` varies run to run, as expected).
