"""
Utility script to generate a synthetic 10,000-row OHLCV dataset for testing.
Not part of the graded pipeline (run.py) — just used to create data.csv.
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(seed=7)

n = 10000
start_price = 100.0

# Simulate a random-walk close price
returns = rng.normal(loc=0.0, scale=0.5, size=n)
close = start_price + np.cumsum(returns)
close = np.maximum(close, 1.0)  # keep prices positive

open_ = close + rng.normal(0, 0.2, size=n)
high = np.maximum(open_, close) + np.abs(rng.normal(0, 0.3, size=n))
low = np.minimum(open_, close) - np.abs(rng.normal(0, 0.3, size=n))
volume = rng.integers(1000, 50000, size=n)

timestamps = pd.date_range("2023-01-01", periods=n, freq="min")

df = pd.DataFrame({
    "timestamp": timestamps,
    "open": open_.round(4),
    "high": high.round(4),
    "low": low.round(4),
    "close": close.round(4),
    "volume": volume,
})

df.to_csv("data.csv", index=False)
print(f"Wrote data.csv with {len(df)} rows")
