"""
generate_dashboard.py — Builds a self-contained, static dashboard.html that
visualizes what run.py does and shows real output from the last run
(metrics.json, run.log, and a sample of the close/rolling_mean/signal series).

This is a bonus presentation layer only — NOT part of the graded pipeline.
The pipeline itself (run.py) has no frontend and needs none to satisfy the
assessment. Run this after run.py to refresh the dashboard with fresh data:

    python generate_dashboard.py
"""

import json
import html
import pandas as pd

CONFIG_PATH = "config.yaml"
DATA_PATH = "data.csv"
METRICS_PATH = "metrics.json"
LOG_PATH = "run.log"
OUT_PATH = "dashboard.html"

WINDOW = 5
SAMPLE_ROWS = 250


def load_chart_sample():
    df = pd.read_csv(DATA_PATH)
    df["rolling_mean"] = df["close"].rolling(window=WINDOW, min_periods=WINDOW).mean()
    df["signal"] = 0
    mask = df["rolling_mean"].notna()
    df.loc[mask, "signal"] = (df.loc[mask, "close"] > df.loc[mask, "rolling_mean"]).astype(int)
    sample = df.head(SAMPLE_ROWS)[["close", "rolling_mean", "signal"]].copy()
    sample["rolling_mean"] = sample["rolling_mean"].fillna(sample["close"])
    return sample.round(3).to_dict(orient="records")


def load_metrics():
    with open(METRICS_PATH) as f:
        return json.load(f)


def load_log():
    with open(LOG_PATH) as f:
        return f.read().strip().split("\n")


def build_html(chart_data, metrics, log_lines):
    log_json = json.dumps(log_lines)
    chart_json = json.dumps(chart_data)
    metrics_json = json.dumps(metrics)

    signal_pct = round(metrics.get("value", 0) * 100, 2)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>run.py — pipeline dashboard</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500;600&display=swap');

  :root {{
    --bg: #0A0E14;
    --bg-panel: #10161F;
    --bg-panel-raised: #151C27;
    --grid: #1C2531;
    --ink: #E7ECF3;
    --ink-dim: #8A97AB;
    --ink-faint: #4E5A6E;
    --buy: #35D07F;
    --sell: #FF6B6B;
    --amber: #F5C451;
    --line: #2A3444;
  }}

  * {{ box-sizing: border-box; margin: 0; padding: 0; }}

  body {{
    background: var(--bg);
    color: var(--ink);
    font-family: 'Inter', sans-serif;
    line-height: 1.5;
    -webkit-font-smoothing: antialiased;
  }}

  body::before {{
    content: "";
    position: fixed;
    inset: 0;
    background-image:
      linear-gradient(var(--grid) 1px, transparent 1px),
      linear-gradient(90deg, var(--grid) 1px, transparent 1px);
    background-size: 48px 48px;
    opacity: 0.35;
    pointer-events: none;
    z-index: 0;
  }}

  .wrap {{
    position: relative;
    z-index: 1;
    max-width: 1040px;
    margin: 0 auto;
    padding: 56px 24px 96px;
  }}

  .mono {{ font-family: 'JetBrains Mono', monospace; }}

  /* ---------- Header / ticker strip ---------- */
  .ticker {{
    display: flex;
    align-items: center;
    gap: 10px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--ink-faint);
    margin-bottom: 40px;
    flex-wrap: wrap;
  }}
  .ticker .dot {{
    width: 6px; height: 6px; border-radius: 50%;
    background: var(--buy);
    box-shadow: 0 0 8px var(--buy);
    animation: pulse 2s ease-in-out infinite;
  }}
  @keyframes pulse {{
    0%, 100% {{ opacity: 1; }}
    50% {{ opacity: 0.35; }}
  }}
  .ticker .sep {{ color: var(--ink-faint); opacity: 0.5; }}
  .ticker .stage {{ color: var(--ink-dim); }}
  .ticker .stage.active {{ color: var(--amber); }}

  /* ---------- Hero ---------- */
  .hero {{
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    gap: 32px;
    padding-bottom: 40px;
    border-bottom: 1px solid var(--line);
    margin-bottom: 40px;
    flex-wrap: wrap;
  }}
  .hero h1 {{
    font-family: 'Space Grotesk', sans-serif;
    font-weight: 700;
    font-size: 42px;
    letter-spacing: -0.02em;
    line-height: 1.05;
    max-width: 560px;
  }}
  .hero h1 .accent {{ color: var(--amber); }}
  .hero p.sub {{
    color: var(--ink-dim);
    font-size: 15px;
    margin-top: 14px;
    max-width: 480px;
  }}
  .hero-stat {{
    text-align: right;
    flex-shrink: 0;
  }}
  .hero-stat .num {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 56px;
    font-weight: 600;
    color: var(--buy);
    line-height: 1;
  }}
  .hero-stat .label {{
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: var(--ink-faint);
    margin-top: 8px;
  }}

  /* ---------- Section headers ---------- */
  .section-head {{
    display: flex;
    align-items: baseline;
    gap: 12px;
    margin-bottom: 20px;
  }}
  .section-head .idx {{
    font-family: 'JetBrains Mono', monospace;
    color: var(--ink-faint);
    font-size: 13px;
  }}
  .section-head h2 {{
    font-family: 'Space Grotesk', sans-serif;
    font-size: 19px;
    font-weight: 600;
  }}
  section {{ margin-bottom: 56px; }}

  /* ---------- Pipeline steps ---------- */
  .steps {{
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 1px;
    background: var(--line);
    border: 1px solid var(--line);
    border-radius: 10px;
    overflow: hidden;
  }}
  .step {{
    background: var(--bg-panel);
    padding: 20px 16px;
  }}
  .step .n {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    color: var(--amber);
    margin-bottom: 10px;
  }}
  .step h3 {{
    font-size: 13.5px;
    font-weight: 600;
    margin-bottom: 6px;
  }}
  .step p {{
    font-size: 12px;
    color: var(--ink-dim);
  }}

  @media (max-width: 760px) {{
    .steps {{ grid-template-columns: 1fr 1fr; }}
  }}

  /* ---------- Metrics cards ---------- */
  .cards {{
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 12px;
  }}
  .card {{
    background: var(--bg-panel);
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 18px 16px;
  }}
  .card .label {{
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: var(--ink-faint);
    margin-bottom: 8px;
  }}
  .card .val {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 20px;
    font-weight: 600;
  }}
  .card.status .val {{ color: var(--buy); }}
  @media (max-width: 760px) {{
    .cards {{ grid-template-columns: 1fr 1fr; }}
  }}

  /* ---------- Chart ---------- */
  .chart-panel {{
    background: var(--bg-panel);
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 24px;
  }}
  .legend {{
    display: flex;
    gap: 20px;
    margin-bottom: 16px;
    font-size: 12px;
    color: var(--ink-dim);
    flex-wrap: wrap;
  }}
  .legend span {{ display: flex; align-items: center; gap: 6px; }}
  .swatch {{ width: 12px; height: 2px; display: inline-block; }}
  .dotswatch {{ width: 8px; height: 8px; border-radius: 50%; display: inline-block; }}
  svg#chart {{ width: 100%; height: auto; display: block; }}
  .chart-caption {{
    margin-top: 12px;
    font-size: 12px;
    color: var(--ink-faint);
  }}

  /* ---------- Terminal ---------- */
  .terminal {{
    background: #070A0F;
    border: 1px solid var(--line);
    border-radius: 10px;
    overflow: hidden;
  }}
  .terminal-bar {{
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 14px;
    background: var(--bg-panel-raised);
    border-bottom: 1px solid var(--line);
  }}
  .terminal-bar .tdot {{ width: 10px; height: 10px; border-radius: 50%; }}
  .terminal-bar .t1 {{ background: #FF6B6B; }}
  .terminal-bar .t2 {{ background: #F5C451; }}
  .terminal-bar .t3 {{ background: #35D07F; }}
  .terminal-bar .fname {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 12px;
    color: var(--ink-faint);
    margin-left: 8px;
  }}
  .terminal-body {{
    padding: 18px 20px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 12.5px;
    line-height: 1.85;
    overflow-x: auto;
  }}
  .log-line {{ white-space: pre; }}
  .log-line .ts {{ color: var(--ink-faint); }}
  .log-line .lvl-INFO {{ color: var(--buy); }}
  .log-line .lvl-ERROR {{ color: var(--sell); }}
  .log-line .msg {{ color: var(--ink); }}

  /* ---------- Overview ---------- */
  .overview {{
    display: grid;
    grid-template-columns: 1.1fr 1fr;
    gap: 32px;
    align-items: start;
  }}
  .overview .lead {{
    font-size: 15px;
    color: var(--ink-dim);
    line-height: 1.7;
  }}
  .overview .lead strong {{ color: var(--ink); font-weight: 600; }}
  .value-props {{
    display: flex;
    flex-direction: column;
    gap: 12px;
  }}
  .value-prop {{
    display: flex;
    gap: 14px;
    background: var(--bg-panel);
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 14px 16px;
  }}
  .value-prop .icon {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 13px;
    color: var(--amber);
    flex-shrink: 0;
    width: 22px;
  }}
  .value-prop h4 {{
    font-size: 13.5px;
    font-weight: 600;
    margin-bottom: 3px;
  }}
  .value-prop p {{
    font-size: 12.5px;
    color: var(--ink-dim);
  }}
  @media (max-width: 760px) {{
    .overview {{ grid-template-columns: 1fr; }}
  }}

  /* ---------- Tech stack badges ---------- */
  .badges {{
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 20px;
  }}
  .badge {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    letter-spacing: 0.03em;
    color: var(--ink-dim);
    background: var(--bg-panel);
    border: 1px solid var(--line);
    border-radius: 20px;
    padding: 6px 12px;
  }}

  /* ---------- Quick start ---------- */
  .quickstart {{
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
  }}
  .qs-card {{
    background: var(--bg-panel);
    border: 1px solid var(--line);
    border-radius: 10px;
    overflow: hidden;
  }}
  .qs-head {{
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 16px;
    border-bottom: 1px solid var(--line);
  }}
  .qs-head h4 {{
    font-size: 13.5px;
    font-weight: 600;
  }}
  .qs-head span {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 10.5px;
    color: var(--ink-faint);
    text-transform: uppercase;
    letter-spacing: 0.06em;
  }}
  .qs-body {{
    padding: 16px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 12px;
    line-height: 2;
    color: var(--ink-dim);
  }}
  .qs-body .cmd {{
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    padding: 2px 0;
  }}
  .qs-body .cmd code {{
    color: var(--buy);
    white-space: nowrap;
    overflow-x: auto;
    display: block;
    max-width: 100%;
  }}
  .copy-btn {{
    background: var(--bg-panel-raised);
    border: 1px solid var(--line);
    color: var(--ink-faint);
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    padding: 3px 8px;
    border-radius: 5px;
    cursor: pointer;
    flex-shrink: 0;
    transition: color 0.15s, border-color 0.15s;
  }}
  .copy-btn:hover {{ color: var(--ink); border-color: var(--ink-faint); }}
  .copy-btn.copied {{ color: var(--buy); border-color: var(--buy); }}
  @media (max-width: 760px) {{
    .quickstart {{ grid-template-columns: 1fr; }}
  }}

  /* ---------- Footer note ---------- */
  .note {{
    border-top: 1px solid var(--line);
    padding-top: 24px;
    font-size: 12.5px;
    color: var(--ink-faint);
  }}
  .note code {{
    font-family: 'JetBrains Mono', monospace;
    background: var(--bg-panel);
    padding: 2px 6px;
    border-radius: 4px;
    color: var(--ink-dim);
  }}
</style>
</head>
<body>
<div class="wrap">

  <div class="ticker">
    <span class="dot"></span>
    <span class="stage active">CONFIG</span><span class="sep">/</span>
    <span class="stage active">LOAD</span><span class="sep">/</span>
    <span class="stage active">ROLLING&nbsp;MEAN</span><span class="sep">/</span>
    <span class="stage active">SIGNAL</span><span class="sep">/</span>
    <span class="stage active">METRICS</span>
    <span class="sep">&nbsp;·&nbsp;</span>
    <span>seed={metrics.get('seed')}</span>
    <span class="sep">·</span>
    <span>window={WINDOW}</span>
    <span class="sep">·</span>
    <span>v{metrics.get('version','').lstrip('v')}</span>
  </div>

  <div class="hero">
    <div>
      <h1>10,000 rows of OHLCV in.<br>One <span class="accent">signal</span> out.</h1>
      <p class="sub">A deterministic batch job: it reads price data, tracks a rolling
      average, and flags every row where price is trading above its own recent trend.
      Same config and seed always produce the same result — locally or in Docker.</p>
    </div>
    <div class="hero-stat">
      <div class="num">{signal_pct}%</div>
      <div class="label">signal rate</div>
    </div>
  </div>

  <section>
    <div class="section-head">
      <span class="idx mono">01</span>
      <h2>What this is, in plain terms</h2>
    </div>
    <div class="overview">
      <div class="lead">
        <p>This is a small, self-contained data job: point it at a price
        history file, and it tells you — for every single row — whether the
        price was trading <strong>above or below its own recent average</strong>.
        That's the "signal."</p>
        <p style="margin-top:14px;">Nothing about it depends on luck or timing.
        <strong>Same input, same settings, same answer</strong> — every time,
        on any machine, whether it's run directly or inside a Docker
        container. That predictability is the actual point: it's meant to
        slot into a larger pipeline (e.g. a trading system) as a trustworthy,
        repeatable building block, not a one-off script.</p>
        <div class="badges">
          <span class="badge">Python 3.9+</span>
          <span class="badge">pandas</span>
          <span class="badge">numpy</span>
          <span class="badge">YAML config</span>
          <span class="badge">Docker</span>
          <span class="badge">CLI</span>
        </div>
      </div>
      <div class="value-props">
        <div class="value-prop">
          <div class="icon">01</div>
          <div><h4>Reproducible</h4><p>A fixed seed and versioned config mean two people running this get the exact same numbers.</p></div>
        </div>
        <div class="value-prop">
          <div class="icon">02</div>
          <div><h4>Observable</h4><p>Every step is logged, and results come out as clean JSON — easy to read by a person or a monitoring system.</p></div>
        </div>
        <div class="value-prop">
          <div class="icon">03</div>
          <div><h4>Deployment-ready</h4><p>Packaged in Docker. One command builds it, one command runs it, anywhere.</p></div>
        </div>
      </div>
    </div>
  </section>

  <section>
    <div class="section-head">
      <span class="idx mono">02</span>
      <h2>What run.py actually does</h2>
    </div>
    <div class="steps">
      <div class="step">
        <div class="n">01</div>
        <h3>Load config</h3>
        <p>Parses config.yaml, checks seed / window / version are present and valid, seeds numpy.</p>
      </div>
      <div class="step">
        <div class="n">02</div>
        <h3>Load data</h3>
        <p>Reads data.csv, validates it's non-empty, parsable, and has a close column.</p>
      </div>
      <div class="step">
        <div class="n">03</div>
        <h3>Rolling mean</h3>
        <p>Averages close over the last N rows, N = window from config.</p>
      </div>
      <div class="step">
        <div class="n">04</div>
        <h3>Signal</h3>
        <p>1 if close is above its rolling mean, else 0. First N-1 rows default to 0.</p>
      </div>
      <div class="step">
        <div class="n">05</div>
        <h3>Metrics + logs</h3>
        <p>Writes metrics.json and run.log, prints the result, exits 0 or non-zero.</p>
      </div>
    </div>
  </section>

  <section>
    <div class="section-head">
      <span class="idx mono">03</span>
      <h2>Last run — metrics.json</h2>
    </div>
    <div class="cards">
      <div class="card"><div class="label">Rows processed</div><div class="val">{metrics.get('rows_processed','—'):,}</div></div>
      <div class="card"><div class="label">Signal rate</div><div class="val">{metrics.get('value','—')}</div></div>
      <div class="card"><div class="label">Latency</div><div class="val">{metrics.get('latency_ms','—')} ms</div></div>
      <div class="card"><div class="label">Seed</div><div class="val">{metrics.get('seed','—')}</div></div>
      <div class="card status"><div class="label">Status</div><div class="val">{metrics.get('status','—')}</div></div>
    </div>
  </section>

  <section>
    <div class="section-head">
      <span class="idx mono">04</span>
      <h2>Close price vs. rolling mean — first {SAMPLE_ROWS} rows</h2>
    </div>
    <div class="chart-panel">
      <div class="legend">
        <span><span class="swatch" style="background:var(--ink-dim)"></span> close</span>
        <span><span class="swatch" style="background:var(--amber)"></span> rolling mean (window={WINDOW})</span>
        <span><span class="dotswatch" style="background:var(--buy)"></span> signal = 1 (close above trend)</span>
        <span><span class="dotswatch" style="background:var(--sell)"></span> signal = 0</span>
      </div>
      <svg id="chart" viewBox="0 0 960 320" xmlns="http://www.w3.org/2000/svg"></svg>
      <div class="chart-caption">Rendered directly from this run's output — not a mockup.</div>
    </div>
  </section>

  <section>
    <div class="section-head">
      <span class="idx mono">05</span>
      <h2>run.log</h2>
    </div>
    <div class="terminal">
      <div class="terminal-bar">
        <span class="tdot t1"></span><span class="tdot t2"></span><span class="tdot t3"></span>
        <span class="fname">run.log</span>
      </div>
      <div class="terminal-body" id="logbody"></div>
    </div>
  </section>

  <section>
    <div class="section-head">
      <span class="idx mono">06</span>
      <h2>Try it yourself</h2>
    </div>
    <div class="quickstart">
      <div class="qs-card">
        <div class="qs-head">
          <h4>Run locally</h4>
          <span>Python</span>
        </div>
        <div class="qs-body">
          <div class="cmd"><code>pip install -r requirements.txt</code><button class="copy-btn" data-copy="pip install -r requirements.txt">copy</button></div>
          <div class="cmd"><code>python run.py --input data.csv --config config.yaml --output metrics.json --log-file run.log</code><button class="copy-btn" data-copy="python run.py --input data.csv --config config.yaml --output metrics.json --log-file run.log">copy</button></div>
        </div>
      </div>
      <div class="qs-card">
        <div class="qs-head">
          <h4>Run in Docker</h4>
          <span>No setup needed</span>
        </div>
        <div class="qs-body">
          <div class="cmd"><code>docker build -t mlops-task .</code><button class="copy-btn" data-copy="docker build -t mlops-task .">copy</button></div>
          <div class="cmd"><code>docker run --rm mlops-task</code><button class="copy-btn" data-copy="docker run --rm mlops-task">copy</button></div>
          <div class="cmd"><code>&nbsp;</code></div>
          <div class="cmd"><code style="color:var(--ink-faint)">→ prints the metrics JSON, exits 0</code></div>
        </div>
      </div>
    </div>
  </section>

  <div class="note">
    Generated by <code>generate_dashboard.py</code> from a real run's
    <code>metrics.json</code>, <code>run.log</code>, and <code>data.csv</code>.
    This page is a presentation layer only — the graded pipeline is
    <code>run.py</code>, run via CLI or Docker with no frontend dependency.
  </div>

</div>

<script>
  const chartData = {chart_json};
  const logLines = {log_json};

  // ---- render log ----
  const logbody = document.getElementById('logbody');
  logLines.forEach(line => {{
    const parts = line.split(' | ');
    const div = document.createElement('div');
    div.className = 'log-line';
    if (parts.length >= 3) {{
      const ts = parts[0];
      const lvl = parts[1].trim();
      const msg = parts.slice(2).join(' | ');
      div.innerHTML = `<span class="ts">${{ts}}</span>  <span class="lvl-${{lvl}}">${{lvl.padEnd(5)}}</span>  <span class="msg">${{msg}}</span>`;
    }} else {{
      div.textContent = line;
    }}
    logbody.appendChild(div);
  }});

  // ---- render chart ----
  const svg = document.getElementById('chart');
  const W = 960, H = 320, padL = 44, padR = 12, padT = 12, padB = 12;
  const closes = chartData.map(d => d.close);
  const means = chartData.map(d => d.rolling_mean);
  const all = closes.concat(means);
  const minV = Math.min(...all), maxV = Math.max(...all);
  const n = chartData.length;

  const x = i => padL + (i / (n - 1)) * (W - padL - padR);
  const y = v => padT + (1 - (v - minV) / (maxV - minV)) * (H - padT - padB);

  function pathFor(key) {{
    return chartData.map((d, i) => `${{i === 0 ? 'M' : 'L'}} ${{x(i).toFixed(2)}} ${{y(d[key]).toFixed(2)}}`).join(' ');
  }}

  let svgContent = '';

  // gridlines
  for (let g = 0; g <= 4; g++) {{
    const gy = padT + (g / 4) * (H - padT - padB);
    svgContent += `<line x1="${{padL}}" y1="${{gy.toFixed(1)}}" x2="${{W - padR}}" y2="${{gy.toFixed(1)}}" stroke="#1C2531" stroke-width="1"/>`;
  }}

  // close line
  svgContent += `<path d="${{pathFor('close')}}" fill="none" stroke="#8A97AB" stroke-width="1.5"/>`;
  // rolling mean line
  svgContent += `<path d="${{pathFor('rolling_mean')}}" fill="none" stroke="#F5C451" stroke-width="1.8"/>`;

  // signal dots (sparse, every 4th point to avoid clutter)
  chartData.forEach((d, i) => {{
    if (i % 4 !== 0) return;
    const color = d.signal === 1 ? '#35D07F' : '#FF6B6B';
    svgContent += `<circle cx="${{x(i).toFixed(2)}}" cy="${{y(d.close).toFixed(2)}}" r="2.4" fill="${{color}}" opacity="0.85"/>`;
  }});

  svg.innerHTML = svgContent;

  // ---- copy buttons ----
  document.querySelectorAll('.copy-btn').forEach(btn => {{
    btn.addEventListener('click', () => {{
      const text = btn.getAttribute('data-copy');
      navigator.clipboard.writeText(text).then(() => {{
        const original = btn.textContent;
        btn.textContent = 'copied';
        btn.classList.add('copied');
        setTimeout(() => {{
          btn.textContent = original;
          btn.classList.remove('copied');
        }}, 1400);
      }});
    }});
  }});
</script>
</body>
</html>
"""


def main():
    chart_data = load_chart_sample()
    metrics = load_metrics()
    log_lines = load_log()
    out = build_html(chart_data, metrics, log_lines)
    with open(OUT_PATH, "w") as f:
        f.write(out)
    print(f"Wrote {OUT_PATH}")


if __name__ == "__main__":
    main()
