#!/usr/bin/env python3
"""
run.py — Minimal MLOps-style batch job.

Loads a YAML config, reads an OHLCV CSV, computes a rolling mean on `close`,
derives a binary signal (close > rolling_mean), and writes structured
metrics (metrics.json) plus detailed logs (run.log).

Usage:
    python run.py --input data.csv --config config.yaml --output metrics.json --log-file run.log
"""

import argparse
import json
import logging
import os
import sys
import time

import numpy as np
import pandas as pd
import yaml

REQUIRED_CONFIG_FIELDS = ("seed", "window", "version")


def parse_args():
    parser = argparse.ArgumentParser(description="Rolling-mean signal batch job")
    parser.add_argument("--input", required=True, help="Path to input CSV (OHLCV data)")
    parser.add_argument("--config", required=True, help="Path to YAML config file")
    parser.add_argument("--output", required=True, help="Path to write metrics JSON")
    parser.add_argument("--log-file", required=True, help="Path to write log file")
    return parser.parse_args()


def setup_logging(log_file):
    logger = logging.getLogger("mlops_task")
    logger.setLevel(logging.INFO)
    logger.handlers = []  # avoid duplicate handlers on repeated calls

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s", datefmt="%Y-%m-%dT%H:%M:%S%z"
    )

    file_handler = logging.FileHandler(log_file, mode="w")
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(fmt)
    logger.addHandler(stream_handler)

    return logger


def write_metrics(output_path, payload, logger):
    with open(output_path, "w") as f:
        json.dump(payload, f, indent=2)
    logger.info(f"Metrics written to {output_path}: {payload}")


def fail(output_path, version, message, logger):
    logger.error(f"Job failed: {message}")
    payload = {
        "version": version if version else "unknown",
        "status": "error",
        "error_message": message,
    }
    write_metrics(output_path, payload, logger)
    logger.info("Job end | status=error")


def load_and_validate_config(config_path, logger):
    if not os.path.isfile(config_path):
        raise ValueError(f"Config file not found: {config_path}")

    try:
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML in config file: {e}")

    if not isinstance(config, dict):
        raise ValueError("Invalid config structure: expected a YAML mapping/object")

    missing = [field for field in REQUIRED_CONFIG_FIELDS if field not in config]
    if missing:
        raise ValueError(f"Missing required config field(s): {', '.join(missing)}")

    seed, window, version = config["seed"], config["window"], config["version"]

    if not isinstance(seed, int):
        raise ValueError(f"Config field 'seed' must be an integer, got: {seed!r}")
    if not isinstance(window, int) or window < 1:
        raise ValueError(f"Config field 'window' must be a positive integer, got: {window!r}")
    if not isinstance(version, str):
        raise ValueError(f"Config field 'version' must be a string, got: {version!r}")

    logger.info(f"Config loaded + validated: seed={seed}, window={window}, version={version}")
    return {"seed": seed, "window": window, "version": version}


def load_and_validate_data(input_path, logger):
    if not os.path.isfile(input_path):
        raise ValueError(f"Input file not found: {input_path}")

    if os.path.getsize(input_path) == 0:
        raise ValueError(f"Input file is empty: {input_path}")

    try:
        df = pd.read_csv(input_path)
    except pd.errors.EmptyDataError:
        raise ValueError(f"Input file has no parsable data: {input_path}")
    except pd.errors.ParserError as e:
        raise ValueError(f"Invalid CSV format: {e}")

    if df.empty:
        raise ValueError(f"Input file contains no rows: {input_path}")

    if "close" not in df.columns:
        raise ValueError("Missing required column: 'close'")

    if not pd.api.types.is_numeric_dtype(df["close"]):
        df["close"] = pd.to_numeric(df["close"], errors="coerce")
        if df["close"].isna().all():
            raise ValueError("Column 'close' contains no valid numeric data")

    logger.info(f"Rows loaded: {len(df)} from {input_path}")
    return df


def compute_rolling_mean_and_signal(df, window, logger):
    df = df.copy(deep=True)
    df.loc[:, "rolling_mean"] = df["close"].rolling(window=window, min_periods=window).mean()
    logger.info(f"Rolling mean computed with window={window}")

    # First (window - 1) rows have no defined rolling mean (NaN) -> excluded from signal
    # computation and treated as signal = 0 by convention (no signal available yet).
    df.loc[:, "signal"] = 0
    valid_mask = df["rolling_mean"].notna()
    df.loc[valid_mask, "signal"] = (df.loc[valid_mask, "close"] > df.loc[valid_mask, "rolling_mean"]).astype(int)

    logger.info(
        f"Signal generated: {int(valid_mask.sum())} rows with valid rolling mean, "
        f"{int((~valid_mask).sum())} warm-up rows defaulted to signal=0"
    )
    return df


def main():
    args = parse_args()
    logger = setup_logging(args.log_file)
    start_time = time.perf_counter()
    version_for_error = "v1"

    logger.info("Job start")
    logger.info(f"Args: input={args.input}, config={args.config}, output={args.output}, log_file={args.log_file}")

    try:
        config = load_and_validate_config(args.config, logger)
        version_for_error = config["version"]

        np.random.seed(config["seed"])
        logger.info(f"Random seed set: {config['seed']}")

        df = load_and_validate_data(args.input, logger)

        window = config["window"]
        if window > len(df):
            raise ValueError(
                f"Config 'window' ({window}) is larger than number of rows ({len(df)})"
            )

        df = compute_rolling_mean_and_signal(df, window, logger)

        rows_processed = int(len(df))
        signal_rate = float(df["signal"].mean())
        elapsed_ms = int(round((time.perf_counter() - start_time) * 1000))

        logger.info(
            f"Metrics summary: rows_processed={rows_processed}, "
            f"signal_rate={signal_rate:.4f}, latency_ms={elapsed_ms}"
        )

        payload = {
            "version": config["version"],
            "rows_processed": rows_processed,
            "metric": "signal_rate",
            "value": round(signal_rate, 4),
            "latency_ms": elapsed_ms,
            "seed": config["seed"],
            "status": "success",
        }
        write_metrics(args.output, payload, logger)
        logger.info("Job end | status=success")
        print(json.dumps(payload, indent=2))
        sys.exit(0)

    except Exception as e:
        fail(args.output, version_for_error, str(e), logger)
        print(json.dumps({
            "version": version_for_error,
            "status": "error",
            "error_message": str(e),
        }, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
